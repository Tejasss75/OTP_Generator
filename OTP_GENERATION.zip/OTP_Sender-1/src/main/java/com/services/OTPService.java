package com.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.twilio.rest.api.v2010.account.Message;
import com.configuration.TwilioCongfiguration;
import com.twilio.type.PhoneNumber;


@Service
public class OTPService {
	@Autowired
	private TwilioCongfiguration congfiguration;

	public void sendOTP(String mobileNo, String otp) {
		try {
			Message.creator(new PhoneNumber(mobileNo), new PhoneNumber(congfiguration.getContactNo()),
					"Your OTP is " + otp).create();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
