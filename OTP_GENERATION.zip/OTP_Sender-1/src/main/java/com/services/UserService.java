package com.services;

public interface UserService {
	public String generateOIP(String username);
		
}
