package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.services.OTPService;
import com.services.UserService;

import ch.qos.logback.core.model.Model;

@Controller
public class UserController {
	String otp;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private OTPService service;
	
	@GetMapping("/login")
	public String getLogin(Model model) {
		return "adminlogin";
	}
	
	@GetMapping("loginsts")
	public String getOTP(@RequestParam("username") String Username) {
		String demo = "+91"+Username;
		otp=userService.generateOIP(Username);
		service.sendOTP(Username, demo);
		return "sucess";
		
	}
}
